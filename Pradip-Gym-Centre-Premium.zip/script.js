
function calcBMI(){
let h=parseFloat(document.getElementById('height').value)/100;
let w=parseFloat(document.getElementById('weight').value);
if(!h||!w){return;}
let bmi=(w/(h*h)).toFixed(1);
document.getElementById('result').innerHTML='Your BMI: '+bmi;
}
const testimonials=[
'"Best gym experience ever!"',
'"Lost 10kg in 3 months."',
'"Friendly trainers and great equipment."'
];
let i=0;
setInterval(()=>{
i=(i+1)%testimonials.length;
document.getElementById('testimonial').innerText=testimonials[i];
},3000);
